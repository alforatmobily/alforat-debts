import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import jsPDF from "jspdf";
import * as XLSX from "xlsx";

export default function Home() {
  const [accounts, setAccounts] = useState([]);
  const [name, setName] = useState("");
  const [balance, setBalance] = useState("");
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [transactionAmount, setTransactionAmount] = useState("");
  const [transactionNote, setTransactionNote] = useState("");
  const [search, setSearch] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [password, setPassword] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [newPassword, setNewPassword] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("accounts");
    const savedTheme = localStorage.getItem("theme");
    const savedPass = localStorage.getItem("passcode");
    if (stored) setAccounts(JSON.parse(stored));
    if (savedTheme === "dark") setDarkMode(true);
    if (!savedPass) localStorage.setItem("passcode", "1234");
  }, []);

  useEffect(() => {
    localStorage.setItem("accounts", JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem("theme", darkMode ? "dark" : "light");
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  const handleLogin = () => {
    const savedPass = localStorage.getItem("passcode");
    if (password === savedPass) {
      setAuthenticated(true);
    } else {
      alert("كلمة المرور غير صحيحة");
    }
  };

  const handleChangePassword = () => {
    if (!newPassword) {
      alert("يرجى إدخال كلمة مرور جديدة");
      return;
    }
    localStorage.setItem("passcode", newPassword);
    alert("تم تغيير كلمة المرور بنجاح");
    setNewPassword("");
  };

  const toggleTheme = () => setDarkMode(!darkMode);

  const backupData = () => {
    const blob = new Blob([JSON.stringify(accounts)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "backup_accounts.json";
    a.click();
  };

  const restoreData = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = JSON.parse(evt.target.result);
        setAccounts(data);
      } catch {
        alert("ملف غير صالح");
      }
    };
    reader.readAsText(file);
  };

  if (!authenticated) {
    return (
      <div className="p-4 max-w-sm mx-auto text-center">
        <h2 className="text-xl font-bold mb-4">تسجيل الدخول</h2>
        <input
          type="password"
          placeholder="أدخل كلمة المرور"
          className="border p-2 rounded w-full mb-4"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <Button onClick={handleLogin} className="w-full">دخول</Button>
      </div>
    );
  }

  return (
    <div className={"p-4 max-w-md mx-auto " + (darkMode ? "bg-gray-900 text-white" : "")}> 
      <div className="flex justify-between items-center mb-4">
        <Button onClick={toggleTheme}>{darkMode ? "☀️" : "🌙"}</Button>
        <Button onClick={backupData}>نسخ احتياطي</Button>
        <input type="file" onChange={restoreData} className="hidden" id="fileRestore" />
        <label htmlFor="fileRestore" className="cursor-pointer">استعادة</label>
      </div>

      <div className="mb-4">
        <h2 className="text-lg font-semibold mb-2">تغيير كلمة المرور</h2>
        <input
          type="password"
          placeholder="كلمة المرور الجديدة"
          className="border p-2 rounded w-full mb-2"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <Button onClick={handleChangePassword} className="w-full">تحديث كلمة المرور</Button>
      </div>

      {/* بقية المكونات */}
    </div>
  );
}